package com.acetracker.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.acetracker.viewmodel.TrainingViewModel
import kotlin.math.roundToInt

@Composable
fun GoalSettingsScreen(
    viewModel: TrainingViewModel,
    onNavigateBack: () -> Unit
) {
    val goals by viewModel.goals.collectAsState()

    val currentPrecision = goals.find { it.metric == "precision" }?.value ?: 80
    val currentSeries    = goals.find { it.metric == "series"    }?.value ?: 10

    var precisionSlider by remember(currentPrecision) { mutableFloatStateOf(currentPrecision.toFloat()) }
    var seriesSlider    by remember(currentSeries)    { mutableFloatStateOf(currentSeries.toFloat()) }
    var saved           by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        Text("Configurar objetivos", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)

        Text(
            "Define tus metas personales. La pantalla de estadísticas te mostrará si las estás cumpliendo.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        GoalSliderCard(
            title       = "🎯  Objetivo de precisión",
            description = "% mínimo de golpes buenos que quieres mantener",
            value       = precisionSlider,
            valueLabel  = "${precisionSlider.roundToInt()}%",
            valueRange  = 50f..100f,
            steps       = 49,
            onValueChange = { precisionSlider = it; saved = false }
        )

        GoalSliderCard(
            title       = "📋  Objetivo de series",
            description = "Número mínimo de series que quieres completar por sesión",
            value       = seriesSlider,
            valueLabel  = "${seriesSlider.roundToInt()} series",
            valueRange  = 1f..30f,
            steps       = 28,
            onValueChange = { seriesSlider = it; saved = false }
        )

        if (saved) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("✅  Objetivos guardados correctamente.", modifier = Modifier.padding(16.dp),
                    color = MaterialTheme.colorScheme.onPrimaryContainer)
            }
        }

        Button(onClick = {
            viewModel.saveGoal("precision", precisionSlider.roundToInt())
            viewModel.saveGoal("series",    seriesSlider.roundToInt())
            saved = true
        }, modifier = Modifier.fillMaxWidth()) { Text("Guardar objetivos") }

        OutlinedButton(onClick = onNavigateBack, modifier = Modifier.fillMaxWidth()) { Text("Volver") }
    }
}

@Composable
private fun GoalSliderCard(
    title: String, description: String, value: Float, valueLabel: String,
    valueRange: ClosedFloatingPointRange<Float>, steps: Int, onValueChange: (Float) -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth(), elevation = CardDefaults.cardElevation(2.dp)) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Text(description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(12.dp))
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Slider(value = value, onValueChange = onValueChange, valueRange = valueRange, steps = steps, modifier = Modifier.weight(1f))
                Spacer(Modifier.width(12.dp))
                Text(valueLabel, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            }
        }
    }
}
