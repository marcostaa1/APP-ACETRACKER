package com.acetracker.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface TrainingDao {

    // ── Trainings ──────────────────────────────────────────────────────────
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTraining(training: Training)

    @Transaction
    @Query("SELECT * FROM trainings ORDER BY dateMillis DESC")
    fun getTrainingsWithStats(): Flow<List<TrainingWithStats>>

    // ── Statistics ─────────────────────────────────────────────────────────
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStatistic(statistic: Statistic)

    // ── Goals ──────────────────────────────────────────────────────────────
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertGoal(goal: Goal)

    @Query("SELECT * FROM goals")
    fun getAllGoals(): Flow<List<Goal>>
}
