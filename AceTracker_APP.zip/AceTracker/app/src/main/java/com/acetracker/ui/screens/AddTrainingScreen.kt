package com.acetracker.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.acetracker.viewmodel.TrainingViewModel

val TRAINING_TYPES = listOf("Drive", "Saques", "Volea", "Smash", "Resto", "Partido completo")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddTrainingScreen(
    viewModel: TrainingViewModel,
    onNavigateBack: () -> Unit
) {
    var selectedType  by remember { mutableStateOf(TRAINING_TYPES[0]) }
    var dropdownOpen  by remember { mutableStateOf(false) }
    var duration      by remember { mutableStateOf("") }
    var series        by remember { mutableStateOf("") }
    var precision     by remember { mutableStateOf("") }
    var notes         by remember { mutableStateOf("") }
    var errorMsg      by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Registrar Entrenamiento", style = MaterialTheme.typography.headlineSmall,
            modifier = Modifier.padding(bottom = 4.dp))

        ExposedDropdownMenuBox(expanded = dropdownOpen, onExpandedChange = { dropdownOpen = !dropdownOpen }) {
            OutlinedTextField(
                value = selectedType, onValueChange = {}, readOnly = true,
                label = { Text("Tipo de entrenamiento") },
                trailingIcon = { Icon(Icons.Default.ArrowDropDown, null) },
                modifier = Modifier.fillMaxWidth().menuAnchor()
            )
            ExposedDropdownMenu(expanded = dropdownOpen, onDismissRequest = { dropdownOpen = false }) {
                TRAINING_TYPES.forEach { type ->
                    DropdownMenuItem(text = { Text(type) }, onClick = { selectedType = type; dropdownOpen = false })
                }
            }
        }

        OutlinedTextField(value = duration, onValueChange = { duration = it },
            label = { Text("Duración (minutos)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth())

        OutlinedTextField(value = series, onValueChange = { series = it },
            label = { Text("Series completadas") },
            placeholder = { Text("Ej: 8  (cuántas cestas/series hiciste)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth())

        OutlinedTextField(value = precision, onValueChange = { if (it.length <= 3) precision = it },
            label = { Text("Precisión (% de golpes buenos)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth())

        OutlinedTextField(value = notes, onValueChange = { notes = it },
            label = { Text("Notas (opcional)") }, minLines = 2,
            modifier = Modifier.fillMaxWidth())

        errorMsg?.let { Text(it, color = MaterialTheme.colorScheme.error) }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onNavigateBack, modifier = Modifier.weight(1f)) { Text("Cancelar") }
            Button(onClick = {
                val durInt  = duration.toIntOrNull()
                val serInt  = series.toIntOrNull()
                val precInt = precision.toIntOrNull()
                when {
                    durInt  == null || durInt  <= 0        -> errorMsg = "Introduce una duración válida."
                    serInt  == null || serInt  <= 0        -> errorMsg = "Introduce el número de series completadas."
                    precInt == null || precInt !in 0..100  -> errorMsg = "La precisión debe estar entre 0 y 100."
                    else -> { viewModel.saveTraining(selectedType, durInt, serInt, precInt, notes); onNavigateBack() }
                }
            }, modifier = Modifier.weight(1f)) { Text("Guardar") }
        }
    }
}
