package com.acetracker.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.acetracker.data.AceTrackerDatabase
import com.acetracker.data.Goal
import com.acetracker.data.Statistic
import com.acetracker.data.Training
import com.acetracker.data.TrainingRepository
import com.acetracker.data.TrainingWithStats
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class TrainingViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: TrainingRepository = TrainingRepository(
        AceTrackerDatabase.getInstance(application).trainingDao()
    )

    // ── Trainings ──────────────────────────────────────────────────────────
    val trainings: StateFlow<List<TrainingWithStats>> = repository.trainingsWithStats
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun saveTraining(type: String, duration: Int, completedSeries: Int, precision: Int, notes: String = "") {
        viewModelScope.launch {
            val training = Training(type = type, durationMin = duration, notes = notes)
            val stats = Statistic(
                trainingId          = training.id,
                completedSeries     = completedSeries,
                precisionPercentage = precision
            )
            repository.addTraining(training, stats)
        }
    }

    // ── Goals ──────────────────────────────────────────────────────────────
    val goals: StateFlow<List<Goal>> = repository.goals
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun saveGoal(metric: String, value: Int) {
        viewModelScope.launch { repository.saveGoal(metric, value) }
    }
}
