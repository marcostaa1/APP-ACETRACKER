package com.acetracker.ui

import android.app.Application
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.acetracker.ui.screens.AddTrainingScreen
import com.acetracker.ui.screens.GoalSettingsScreen
import com.acetracker.ui.screens.HomeScreen
import com.acetracker.ui.screens.StatsScreen
import com.acetracker.viewmodel.TrainingViewModel

@Composable
fun AceTrackerApp() {
    val navController = rememberNavController()
    val context = LocalContext.current
    val trainingViewModel: TrainingViewModel = viewModel(
        factory = ViewModelProvider.AndroidViewModelFactory.getInstance(
            context.applicationContext as Application
        )
    )

    NavHost(navController = navController, startDestination = "home") {
        composable("home") {
            HomeScreen(
                viewModel        = trainingViewModel,
                onNavigateToAdd  = { navController.navigate("add") },
                onNavigateToStats = { navController.navigate("stats") }
            )
        }
        composable("add") {
            AddTrainingScreen(
                viewModel       = trainingViewModel,
                onNavigateBack  = { navController.popBackStack() }
            )
        }
        composable("stats") {
            StatsScreen(
                viewModel          = trainingViewModel,
                onNavigateBack     = { navController.popBackStack() },
                onNavigateToGoals  = { navController.navigate("goals") }
            )
        }
        composable("goals") {
            GoalSettingsScreen(
                viewModel      = trainingViewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }
    }
}
