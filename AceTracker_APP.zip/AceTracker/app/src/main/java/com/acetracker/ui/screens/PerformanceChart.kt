package com.acetracker.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.acetracker.data.Statistic
import com.acetracker.data.Training
import java.text.SimpleDateFormat
import java.util.*

data class ChartPoint(
    val label: String,
    val precision: Float,   // 0–100
    val series: Float       // nº series
)

@Composable
fun PerformanceChart(
    trainings: List<Pair<Training, Statistic>>,
    modifier: Modifier = Modifier
) {
    if (trainings.isEmpty()) return

    val dateFormat = SimpleDateFormat("dd/MM", Locale.getDefault())
    val points = trainings
        .sortedBy { it.first.dateMillis }
        .map { (training, stats) ->
            ChartPoint(
                label     = dateFormat.format(Date(training.dateMillis)),
                precision = stats.precisionPercentage.toFloat(),
                series    = stats.completedSeries.toFloat()
            )
        }

    val colorPrecision = Color(0xFF4CAF50)
    val colorSeries    = Color(0xFF2196F3)
    val colorGrid      = Color(0x22000000)
    val colorAxis      = Color(0x55000000)

    val maxSeries = (points.maxOf { it.series } * 1.2f).coerceAtLeast(10f)

    Column(modifier = modifier) {

        Text("Tu rendimiento", style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 8.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.padding(bottom = 12.dp)) {
            LegendItem(color = colorPrecision, label = "Precisión (%)")
            LegendItem(color = colorSeries,    label = "Series completadas")
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(220.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .padding(start = 40.dp, end = 12.dp, top = 12.dp, bottom = 32.dp)
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                val n = points.size
                val stepX = if (n > 1) w / (n - 1).toFloat() else w / 2f

                listOf(0f, 25f, 50f, 75f, 100f).forEach { level ->
                    val y = h - (level / 100f) * h
                    drawLine(colorGrid, Offset(0f, y), Offset(w, y), strokeWidth = 1.dp.toPx())
                }
                drawLine(colorAxis, Offset(0f, 0f), Offset(0f, h), strokeWidth = 1.5f.dp.toPx())
                drawLine(colorAxis, Offset(0f, h),  Offset(w, h),  strokeWidth = 1.5f.dp.toPx())

                fun xOf(i: Int)    = if (n == 1) w / 2f else i * stepX
                fun yOfPrec(p: Float) = h - (p / 100f)     * h
                fun yOfSer(s: Float)  = h - (s / maxSeries) * h

                // Filled area under precision
                if (n > 1) {
                    val area = Path().apply {
                        moveTo(xOf(0), h)
                        lineTo(xOf(0), yOfPrec(points[0].precision))
                        for (i in 1 until n) {
                            val cx = (xOf(i - 1) + xOf(i)) / 2f
                            cubicTo(cx, yOfPrec(points[i-1].precision), cx, yOfPrec(points[i].precision), xOf(i), yOfPrec(points[i].precision))
                        }
                        lineTo(xOf(n-1), h); close()
                    }
                    drawPath(area, colorPrecision.copy(alpha = 0.12f))
                }

                fun drawLine(points: List<ChartPoint>, yFn: (ChartPoint) -> Float, color: Color) {
                    val path = Path()
                    points.forEachIndexed { i, pt ->
                        val x = xOf(i); val y = yFn(pt)
                        if (i == 0) path.moveTo(x, y)
                        else {
                            val cx = (xOf(i-1) + x) / 2f
                            path.cubicTo(cx, yFn(points[i-1]), cx, y, x, y)
                        }
                    }
                    drawPath(path, color, style = Stroke(2.5f.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
                }

                drawLine(points, { yOfPrec(it.precision) }, colorPrecision)
                drawLine(points, { yOfSer(it.series) },     colorSeries)

                val dot = 4.dp.toPx()
                points.forEachIndexed { i, pt ->
                    val x = xOf(i)
                    drawCircle(Color.White, dot + 1.5f.dp.toPx(), Offset(x, yOfPrec(pt.precision)))
                    drawCircle(colorPrecision, dot,               Offset(x, yOfPrec(pt.precision)))
                    drawCircle(Color.White, dot + 1.5f.dp.toPx(), Offset(x, yOfSer(pt.series)))
                    drawCircle(colorSeries, dot,                  Offset(x, yOfSer(pt.series)))
                }
            }

            Column(
                modifier = Modifier.fillMaxHeight().width(36.dp).align(Alignment.CenterStart).offset(x = (-40).dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                listOf("100", "75", "50", "25", "0").forEach { label ->
                    Text(label, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth())
                }
            }

            val n = points.size
            Row(
                modifier = Modifier.fillMaxWidth().align(Alignment.BottomCenter).offset(y = 28.dp),
                horizontalArrangement = if (n == 1) Arrangement.Center else Arrangement.SpaceBetween
            ) {
                points.forEach { pt ->
                    Text(pt.label, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        val last = points.last()
        val prev = points.getOrNull(points.size - 2)

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TrendBadge(Modifier.weight(1f), "Precisión",         "${last.precision.toInt()}%",  prev?.let { last.precision - it.precision }, colorPrecision)
            TrendBadge(Modifier.weight(1f), "Series completadas","${last.series.toInt()}",       prev?.let { last.series    - it.series    }, colorSeries)
        }
    }
}

@Composable
private fun LegendItem(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(color))
        Text(label, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun TrendBadge(modifier: Modifier, label: String, value: String, delta: Float?, color: Color) {
    val arrowColor = when { delta == null -> Color.Gray; delta > 0f -> Color(0xFF4CAF50); delta < 0f -> Color(0xFFF44336); else -> Color.Gray }
    val arrow = when { delta == null || delta == 0f -> "—"; delta!! > 0f -> "▲ +${String.format("%.1f", delta)}"; else -> "▼ ${String.format("%.1f", delta)}" }

    Column(modifier = modifier.clip(RoundedCornerShape(10.dp)).background(color.copy(alpha = 0.1f)).padding(horizontal = 12.dp, vertical = 10.dp)) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = color, fontWeight = FontWeight.SemiBold)
        Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text(arrow, fontSize = 11.sp, color = arrowColor, fontWeight = FontWeight.Medium)
    }
}
