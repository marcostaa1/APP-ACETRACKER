package com.acetracker.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.acetracker.data.Statistic
import com.acetracker.data.Training
import com.acetracker.viewmodel.TrainingViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.InputStreamReader
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

// ── Colores ───────────────────────────────────────────────────────────────────
val GreenDark  = Color(0xFF1B5E20)
val GreenMid   = Color(0xFF2E7D32)
val GreenLight = Color(0xFF4CAF50)

// ── YouTube data ──────────────────────────────────────────────────────────────
data class YoutubeVideo(val title: String, val videoId: String) {
    val watchUrl   get() = "https://www.youtube.com/watch?v=$videoId"
    val thumbUrl   get() = "https://img.youtube.com/vi/$videoId/hqdefault.jpg"
}

// RSS del canal Saque y Red — no requiere API key
// Channel ID obtenido del canal @Saque_y_Red
private const val RSS_URL =
    "https://www.youtube.com/feeds/videos.xml?channel_id=UCdtKSGmhLnpwFMZrSZ2BSOA"

suspend fun fetchLatestVideo(): YoutubeVideo? = withContext(Dispatchers.IO) {
    runCatching {
        val stream  = URL(RSS_URL).openStream()
        val factory = XmlPullParserFactory.newInstance()
        val parser  = factory.newPullParser()
        parser.setInput(InputStreamReader(stream))

        var title   = ""
        var videoId = ""
        var inEntry = false
        var event   = parser.eventType

        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG) {
                when (parser.name) {
                    "entry"       -> inEntry = true
                    "title"       -> if (inEntry && title.isEmpty())   title   = parser.nextText()
                    "yt:videoId"  -> if (inEntry && videoId.isEmpty()) videoId = parser.nextText()
                }
            }
            if (inEntry && title.isNotEmpty() && videoId.isNotEmpty()) break
            event = parser.next()
        }
        stream.close()
        if (videoId.isNotEmpty()) YoutubeVideo(title, videoId) else null
    }.getOrNull()
}

// ── Cálculo de racha ──────────────────────────────────────────────────────────
fun calcularRacha(trainings: List<Long>): Int {
    if (trainings.isEmpty()) return 0
    val hoy = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0);      set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    // Días únicos con entrenamiento, ordenados desc
    val diasUnicos = trainings
        .map { ms ->
            val c = Calendar.getInstance().apply { timeInMillis = ms
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0);      set(Calendar.MILLISECOND, 0) }
            c.timeInMillis
        }
        .toSortedSet(reverseOrder())
        .toList()

    // Si el último día no es hoy ni ayer, racha = 0
    val diffPrimeroDias = TimeUnit.MILLISECONDS.toDays(hoy - diasUnicos.first())
    if (diffPrimeroDias > 1) return 0

    var racha = 1
    for (i in 1 until diasUnicos.size) {
        val diff = TimeUnit.MILLISECONDS.toDays(diasUnicos[i - 1] - diasUnicos[i])
        if (diff == 1L) racha++ else break
    }
    return racha
}

// ── HomeScreen ────────────────────────────────────────────────────────────────
@Composable
fun HomeScreen(
    viewModel: TrainingViewModel,
    onNavigateToAdd: () -> Unit,
    onNavigateToStats: () -> Unit
) {
    val trainingsWithStats by viewModel.trainings.collectAsState()
    val goals              by viewModel.goals.collectAsState()

    val goalPrecision = goals.find { it.metric == "precision" }?.value ?: 80
    val goalSeries    = goals.find { it.metric == "series"    }?.value ?: 10

    val avgPrecision = trainingsWithStats
        .mapNotNull { it.stats?.precisionPercentage }.average().let { if (it.isNaN()) 0.0 else it }
    val avgSeries = trainingsWithStats
        .mapNotNull { it.stats?.completedSeries }.average().let { if (it.isNaN()) 0.0 else it }

    val racha = remember(trainingsWithStats) {
        calcularRacha(trainingsWithStats.map { it.training.dateMillis })
    }

    var youtubeVideo by remember { mutableStateOf<YoutubeVideo?>(null) }
    var videoLoading by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) {
        youtubeVideo = fetchLatestVideo()
        videoLoading = false
    }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 96.dp)
        ) {
            // ── Cabecera verde ────────────────────────────────────────────
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(listOf(Color(0xFF1B5E20), Color(0xFF2E7D32)))
                        )
                        .padding(horizontal = 16.dp, vertical = 20.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("AceTracker", fontSize = 26.sp,
                                    fontWeight = FontWeight.Bold, color = Color.White)
                                Text("Bienvenido de vuelta", fontSize = 13.sp,
                                    color = Color(0xFFA5D6A7))
                            }
                            OutlinedButton(
                                onClick = onNavigateToStats,
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp, Color.White.copy(alpha = 0.6f))
                            ) { Text("Estadísticas", fontSize = 12.sp) }
                        }

                        Spacer(Modifier.height(14.dp))

                        // ── Stats rápidos + racha ─────────────────────────
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            QuickStatCard("${trainingsWithStats.size}", "Sesiones",   Modifier.weight(1f))
                            QuickStatCard("${avgPrecision.toInt()}%",  "Precisión",   Modifier.weight(1f))
                            QuickStatCard("${String.format("%.1f", avgSeries)}", "Series/ses.", Modifier.weight(1f))
                            // Racha
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color.White.copy(alpha = 0.12f))
                                    .padding(vertical = 10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(if (racha > 0) "🔥 $racha" else "—",
                                    fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                Text("Racha", fontSize = 10.sp, color = Color(0xFFA5D6A7))
                            }
                        }
                    }
                }
            }

            // ── Vídeo del día ─────────────────────────────────────────────
            item {
                Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                    Spacer(Modifier.height(16.dp))
                    Text("🎾  Vídeo del día", fontSize = 13.sp, fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(8.dp))
                    YoutubeCard(video = youtubeVideo, loading = videoLoading)
                    Spacer(Modifier.height(16.dp))
                }
            }

            // ── Lista de entrenamientos ───────────────────────────────────
            item {
                Text("Últimos entrenamientos", fontSize = 13.sp, fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp))
                Spacer(Modifier.height(8.dp))
            }

            if (trainingsWithStats.isEmpty()) {
                item {
                    Box(modifier = Modifier.fillMaxWidth().padding(48.dp),
                        contentAlignment = Alignment.Center) {
                        Text("Aún no hay entrenamientos.\n¡Registra el primero!",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 14.sp, textAlign = TextAlign.Center)
                    }
                }
            } else {
                items(trainingsWithStats) { tws ->
                    tws.stats?.let { stats ->
                        TrainingCard(
                            training      = tws.training,
                            stats         = stats,
                            goalPrecision = goalPrecision,
                            goalSeries    = goalSeries,
                            modifier      = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }

        // ── FAB extendido ─────────────────────────────────────────────────
        ExtendedFloatingActionButton(
            onClick           = onNavigateToAdd,
            containerColor    = GreenMid,
            contentColor      = Color.White,
            icon              = { Icon(Icons.Default.Add, null) },
            text              = { Text("Nuevo entrenamiento", fontWeight = FontWeight.Medium) },
            modifier          = Modifier.align(Alignment.BottomEnd).padding(16.dp)
        )
    }
}

// ── Quick stat ────────────────────────────────────────────────────────────────
@Composable
private fun QuickStatCard(value: String, label: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(Color.White.copy(alpha = 0.12f))
            .padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(value, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text(label, fontSize = 10.sp, color = Color(0xFFA5D6A7))
    }
}

// ── YouTube card con thumbnail real ───────────────────────────────────────────
@Composable
private fun YoutubeCard(video: YoutubeVideo?, loading: Boolean) {
    val context = LocalContext.current

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable {
                val url = video?.watchUrl ?: "https://www.youtube.com/@Saque_y_Red/shorts"
                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            },
        shape     = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {

            // ── Thumbnail ─────────────────────────────────────────────────
            Box(
                modifier = Modifier.width(120.dp).fillMaxHeight(),
                contentAlignment = Alignment.Center
            ) {
                if (video != null) {
                    AsyncImage(
                        model = ImageRequest.Builder(context)
                            .data(video.thumbUrl)
                            .crossfade(true)
                            .build(),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    // Placeholder mientras carga
                    Box(modifier = Modifier.fillMaxSize().background(GreenDark))
                }

                // Botón play encima
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.92f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("▶", color = GreenDark, fontSize = 14.sp,
                        modifier = Modifier.offset(x = 1.dp))
                }

                // Badge YT
                Text(
                    "YouTube",
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(4.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(Color.Red)
                        .padding(horizontal = 5.dp, vertical = 2.dp),
                    color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold
                )
            }

            // ── Info ──────────────────────────────────────────────────────
            Column(
                modifier = Modifier
                    .padding(horizontal = 12.dp, vertical = 12.dp)
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Box(modifier = Modifier.size(7.dp).clip(CircleShape).background(GreenLight))
                    Text("Saque y Red", fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }

                Text(
                    text = when {
                        loading      -> "Cargando vídeo del día..."
                        video == null -> "No se pudo cargar el vídeo.\nComprueba tu conexión."
                        else          -> video.title
                    },
                    fontSize  = 13.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines  = 3,
                    overflow  = TextOverflow.Ellipsis,
                    lineHeight = 18.sp
                )

                Spacer(Modifier.height(2.dp))
                Text("Ver en YouTube  ›", fontSize = 12.sp, color = GreenMid,
                    fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

// ── Tarjeta de entrenamiento ──────────────────────────────────────────────────
@Composable
fun TrainingCard(
    training: Training,
    stats: Statistic,
    goalPrecision: Int,
    goalSeries: Int,
    modifier: Modifier = Modifier
) {
    val dateStr = SimpleDateFormat("dd/MM/yyyy · HH:mm", Locale.getDefault())
        .format(Date(training.dateMillis))

    val precOk   = stats.precisionPercentage >= goalPrecision
    val seriesOk = stats.completedSeries >= goalSeries
    val near     = stats.precisionPercentage >= goalPrecision - 10

    val accentColor = when { precOk && seriesOk -> GreenLight; near -> Color(0xFFFF9800); else -> Color(0xFFF44336) }
    val badgeText   = when { precOk && seriesOk -> "+ Objetivo"; near -> "Cerca"; else -> "Bajo objetivo" }
    val badgeBg     = when { precOk && seriesOk -> Color(0xFFE8F5E9); near -> Color(0xFFFFF3E0); else -> Color(0xFFFFEBEE) }
    val badgeFg     = when { precOk && seriesOk -> Color(0xFF2E7D32); near -> Color(0xFFE65100); else -> Color(0xFFB71C1C) }

    Card(modifier = modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(2.dp)) {
        Row(modifier = Modifier.fillMaxWidth()) {
            // Borde lateral color
            Box(modifier = Modifier.width(4.dp).fillMaxHeight().background(accentColor))

            Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp).weight(1f)) {
                Row(modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top) {
                    Column {
                        Text(training.type, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                        Text(dateStr, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text(badgeText,
                        modifier = Modifier.clip(RoundedCornerShape(10.dp))
                            .background(badgeBg).padding(horizontal = 8.dp, vertical = 3.dp),
                        fontSize = 11.sp, color = badgeFg, fontWeight = FontWeight.Medium)
                }

                Spacer(Modifier.height(8.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MetricChip("${training.durationMin} min")
                    MetricChip("${stats.completedSeries} series")
                    MetricChip("${stats.precisionPercentage}% prec.")
                }

                if (training.notes.isNotBlank()) {
                    Spacer(Modifier.height(5.dp))
                    Text(training.notes, fontSize = 12.sp, fontStyle = FontStyle.Italic,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

@Composable
private fun MetricChip(text: String) {
    Text(text,
        modifier = Modifier.clip(RoundedCornerShape(6.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(horizontal = 8.dp, vertical = 3.dp),
        fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
}
