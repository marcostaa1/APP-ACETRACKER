package com.acetracker.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// ── Paleta verde tenis ────────────────────────────────────────────────────────
private val GreenDark    = Color(0xFF1B5E20)
private val GreenMid     = Color(0xFF2E7D32)
private val GreenLight   = Color(0xFF4CAF50)
private val GreenPale    = Color(0xFFE8F5E9)
private val GreenPaleDk  = Color(0xFF1A2E1B)

private val LightColors = lightColorScheme(
    primary            = GreenMid,
    onPrimary          = Color.White,
    primaryContainer   = GreenPale,
    onPrimaryContainer = GreenDark,
    secondary          = GreenLight,
    onSecondary        = Color.White,
    secondaryContainer = Color(0xFFC8E6C9),
    onSecondaryContainer = GreenDark,
    background         = Color(0xFFF9FBF9),
    onBackground       = Color(0xFF1A1C1A),
    surface            = Color.White,
    onSurface          = Color(0xFF1A1C1A),
    surfaceVariant     = Color(0xFFEEF2EE),
    onSurfaceVariant   = Color(0xFF44534A),
    error              = Color(0xFFC62828),
    errorContainer     = Color(0xFFFFEBEE),
    onErrorContainer   = Color(0xFFB71C1C)
)

private val DarkColors = darkColorScheme(
    primary            = GreenLight,
    onPrimary          = GreenDark,
    primaryContainer   = GreenMid,
    onPrimaryContainer = Color(0xFFB7F0B9),
    secondary          = Color(0xFF81C784),
    onSecondary        = GreenDark,
    secondaryContainer = Color(0xFF1B5E20),
    onSecondaryContainer = Color(0xFFB7F0B9),
    background         = Color(0xFF0F1A10),
    onBackground       = Color(0xFFE1E3E0),
    surface            = Color(0xFF161D16),
    onSurface          = Color(0xFFE1E3E0),
    surfaceVariant     = Color(0xFF1E2B1F),
    onSurfaceVariant   = Color(0xFFA0BBAA),
    error              = Color(0xFFEF9A9A),
    errorContainer     = Color(0xFF4E0000),
    onErrorContainer   = Color(0xFFFFCDD2)
)

@Composable
fun AceTrackerTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        content = content
    )
}
