package com.acetracker.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.acetracker.viewmodel.TrainingViewModel
import java.util.Locale

@Composable
fun StatsScreen(
    viewModel: TrainingViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToGoals: () -> Unit
) {
    val trainingsWithStats by viewModel.trainings.collectAsState()
    val goals              by viewModel.goals.collectAsState()

    val goalPrecision = goals.find { it.metric == "precision" }?.value ?: 80
    val goalSeries    = goals.find { it.metric == "series"    }?.value ?: 10

    val entries = trainingsWithStats.mapNotNull { tws -> tws.stats?.let { tws.training to it } }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Estadísticas", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            OutlinedButton(onClick = onNavigateToGoals) { Text("Objetivos") }
        }

        if (entries.isEmpty()) {
            Text("Registra entrenamientos para ver estadísticas.")
        } else {
            val avgPrecision  = entries.map { it.second.precisionPercentage }.average()
            val avgSeries     = entries.map { it.second.completedSeries }.average()
            val totalDuration = entries.sumOf { it.first.durationMin }
            val maxDuration   = entries.maxOf { it.first.durationMin }

            // ── Gráfico ────────────────────────────────────────────────────
            Card(modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp), elevation = CardDefaults.cardElevation(2.dp)) {
                PerformanceChart(trainings = entries, modifier = Modifier.padding(16.dp))
            }

            // ── Promedios ──────────────────────────────────────────────────
            Card(modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Promedios generales", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("Series medias por sesión: ${String.format(Locale.getDefault(), "%.1f", avgSeries)}")
                    Text("Precisión media: ${String.format(Locale.getDefault(), "%.1f", avgPrecision)}%")
                    Text("Tiempo total entrenado: $totalDuration min")
                    Text("Sesiones registradas: ${entries.size}")
                }
            }

            // ── Comparación con objetivos ──────────────────────────────────
            Card(modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp), elevation = CardDefaults.cardElevation(2.dp)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Comparación con tus objetivos", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    GoalComparisonRow("Precisión",         avgPrecision, goalPrecision.toDouble(), "%")
                    Spacer(Modifier.height(8.dp))
                    GoalComparisonRow("Series por sesión", avgSeries,    goalSeries.toDouble(),    " series")
                }
            }

            // ── Alertas ────────────────────────────────────────────────────
            if (avgPrecision < goalPrecision)
                AlertCard("Tu precisión media (${String.format("%.1f", avgPrecision)}%) está por debajo de tu objetivo ($goalPrecision%). ¡Sigue trabajando!")
            else
                SuccessCard("¡Estás cumpliendo tu objetivo de precisión! Mantén el nivel.")

            if (avgSeries < goalSeries)
                AlertCard("Tu media de series (${String.format("%.1f", avgSeries)}) está por debajo de tu objetivo ($goalSeries series por sesión).")
            else
                SuccessCard("¡Estás alcanzando tu objetivo de series por sesión!")

            if (maxDuration > 120)
                AlertCard("⚠️ Alerta de sobreentrenamiento: has registrado sesiones de más de 120 min. ¡Recuerda descansar!")

            // ── Tendencia ──────────────────────────────────────────────────
            if (entries.size >= 3) {
                val sorted   = entries.sortedBy { it.first.dateMillis }
                val recent   = sorted.takeLast(3)
                val previous = sorted.dropLast(3).takeLast(3)
                if (previous.isNotEmpty()) {
                    val recentPrec = recent.map  { it.second.precisionPercentage }.average()
                    val prevPrec   = previous.map{ it.second.precisionPercentage }.average()
                    val recentSer  = recent.map  { it.second.completedSeries }.average()
                    val prevSer    = previous.map{ it.second.completedSeries }.average()
                    when {
                        recentPrec > prevPrec && recentSer > prevSer ->
                            SuccessCard("📈 Estás mejorando en precisión y series. ¡Buen ritmo!")
                        recentPrec < prevPrec - 5 ->
                            AlertCard("Tu precisión ha caído más de 5 puntos en las últimas sesiones. Revisa tu técnica.")
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        Button(onClick = onNavigateBack, modifier = Modifier.fillMaxWidth()) { Text("Volver") }
    }
}

@Composable
private fun GoalComparisonRow(label: String, actual: Double, goal: Double, unit: String) {
    val progress = (actual / goal).coerceIn(0.0, 1.0).toFloat()
    val color = if (actual >= goal) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error

    Column {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
            Text("${String.format("%.1f", actual)}$unit / ${goal.toInt()}$unit",
                style = MaterialTheme.typography.bodySmall, color = color, fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(4.dp))
        LinearProgressIndicator(progress = progress, modifier = Modifier.fillMaxWidth().height(6.dp), color = color)
    }
}

@Composable
fun AlertCard(message: String) {
    Card(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
        Text(message, modifier = Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onErrorContainer)
    }
}

@Composable
fun SuccessCard(message: String) {
    Card(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
        Text(message, modifier = Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onPrimaryContainer)
    }
}
