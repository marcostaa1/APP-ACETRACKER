package com.acetracker.data

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Relation
import java.util.UUID

@Entity(tableName = "trainings")
data class Training(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val dateMillis: Long = System.currentTimeMillis(),
    val type: String,
    val durationMin: Int,
    val notes: String = ""
)

@Entity(tableName = "statistics")
data class Statistic(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val trainingId: String,
    val completedSeries: Int,
    val precisionPercentage: Int
)

// Goal: metric is the PK ("precision" | "speed")
@Entity(tableName = "goals")
data class Goal(
    @PrimaryKey val metric: String,
    val value: Int,
    val period: String = "weekly"
)

// Result object used in UI – Training + its Statistic joined
data class TrainingWithStats(
    @Embedded val training: Training,
    @Relation(
        parentColumn = "id",
        entityColumn = "trainingId"
    )
    val stats: Statistic?
)
