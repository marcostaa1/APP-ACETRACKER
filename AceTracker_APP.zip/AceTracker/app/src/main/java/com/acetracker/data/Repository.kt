package com.acetracker.data

import kotlinx.coroutines.flow.Flow

class TrainingRepository(private val dao: TrainingDao) {

    // ── Trainings ──────────────────────────────────────────────────────────
    val trainingsWithStats: Flow<List<TrainingWithStats>> = dao.getTrainingsWithStats()

    suspend fun addTraining(training: Training, statistic: Statistic) {
        dao.insertTraining(training)
        dao.insertStatistic(statistic)
    }

    // ── Goals ──────────────────────────────────────────────────────────────
    val goals: Flow<List<Goal>> = dao.getAllGoals()

    suspend fun saveGoal(metric: String, value: Int) {
        dao.upsertGoal(Goal(metric = metric, value = value))
    }
}
